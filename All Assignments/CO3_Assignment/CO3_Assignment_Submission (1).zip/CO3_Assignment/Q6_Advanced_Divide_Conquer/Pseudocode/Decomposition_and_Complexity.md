# Decomposition, recurrence and complexity

Median-of-Medians: groups of five -> medians -> pivot -> partition -> recurse one side; worst-case Θ(n). Meet-in-the-Middle: split n values into halves -> enumerate two sets of 2^(n/2) sums -> complementary lookup.

## Diagram
```mermaid
flowchart TD
 A[Input problem] --> B[Divide into smaller subproblems]
 B --> C[Recursively solve subproblems]
 C --> D[Combine returned results]
 D --> E[Final answer]
```

## Experimental record
Run the Python file in `Implementation_Code`. Record the tested input sizes, measured times, operation counts, and hardware/software environment in the final report. Do not present a single timing as a general performance conclusion.

def insertion_sort(a):
    a=a[:]
    for i in range(1,len(a)):
        x=a[i]; j=i-1
        while j>=0 and a[j]>x: a[j+1]=a[j]; j-=1
        a[j+1]=x
    return a
def median_of_medians_select(a,k):
    if not 0<=k<len(a): raise ValueError("k out of range (zero-based)")
    if len(a)<=5: return insertion_sort(a)[k]
    groups=[a[i:i+5] for i in range(0,len(a),5)]
    medians=[insertion_sort(g)[len(g)//2] for g in groups]
    pivot=median_of_medians_select(medians,len(medians)//2)
    lows=[x for x in a if x<pivot]; highs=[x for x in a if x>pivot]
    equals=[x for x in a if x==pivot]
    if k<len(lows): return median_of_medians_select(lows,k)
    if k<len(lows)+len(equals): return pivot
    return median_of_medians_select(highs,k-len(lows)-len(equals))
def quickselect(a,k):
    if not 0<=k<len(a): raise ValueError("k out of range (zero-based)")
    a=a[:]
    while True:
        pivot=a[len(a)//2]
        lo=[x for x in a if x<pivot]; eq=[x for x in a if x==pivot]; hi=[x for x in a if x>pivot]
        if k<len(lo): a=lo
        elif k<len(lo)+len(eq): return pivot
        else: k-=len(lo)+len(eq); a=hi
def subset_sum_mitm(nums,target):
    mid=len(nums)//2; left=nums[:mid]; right=nums[mid:]
    def sums(a):
        out=[]
        for mask in range(1<<len(a)):
            s=sum(a[i] for i in range(len(a)) if mask>>i&1)
            out.append((s,mask))
        return out
    L=sums(left); R=sums(right); lookup={s:m for s,m in R}
    for s,m in L:
        if target-s in lookup: return True
    return False
if __name__=="__main__":
    data=[12,3,5,7,4,19,26,1,8,2,11]
    k=5
    print("Q6 Median of Medians and Meet-in-the-Middle")
    print(f"{k+1}-th smallest:",median_of_medians_select(data,k),"| QuickSelect:",quickselect(data,k))
    nums=[3,34,4,12,5,2]
    print("Subset sum data:",nums,"target=9","found:",subset_sum_mitm(nums,9))

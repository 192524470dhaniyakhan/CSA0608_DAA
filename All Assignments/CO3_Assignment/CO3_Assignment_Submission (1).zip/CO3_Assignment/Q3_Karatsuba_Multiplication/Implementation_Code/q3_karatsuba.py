def standard_multiply(x,y,counter=None):
    if counter is not None: counter[0]+=1
    return x*y

def karatsuba(x,y,counter=None):
    if counter is not None: counter[0]+=1
    if x<10 or y<10: return x*y
    n=max(len(str(abs(x))),len(str(abs(y))))
    m=n//2
    power=10**m
    a,b=divmod(x,power); c,d=divmod(y,power)
    z0=karatsuba(b,d,counter)
    z2=karatsuba(a,c,counter)
    z1=karatsuba(a+b,c+d,counter)-z2-z0
    return z2*power*power+z1*power+z0

if __name__=="__main__":
    x=12345678; y=87654321
    c1=[0]; c2=[0]
    print("Q3 Karatsuba Multiplication")
    print("Operands:",x,y)
    print("Standard result:",standard_multiply(x,y,c1),"recursive multiply calls:",c1[0])
    print("Karatsuba result:",karatsuba(x,y,c2),"recursive calls:",c2[0])
    print("Correct:",x*y==karatsuba(x,y))

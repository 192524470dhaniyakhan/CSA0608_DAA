## Q3 – Karatsuba
Standard digit-by-digit multiplication has `Θ(n²)` time. Karatsuba replaces four half-size products with three:
`T(n)=3T(n/2)+Θ(n)`. By the Master Theorem, `T(n)=Θ(n^(log₂3)) ≈ Θ(n^1.585)`. For small operands, recursion and splitting overhead can outweigh the asymptotic advantage; record repeated timings over increasing digit lengths before claiming a crossover.

# Decomposition, recurrence and complexity

n-digit operands -> high/low halves -> three recursive products z0,z1,z2 -> recombine. T(n)=3T(n/2)+Θ(n)=Θ(n^1.585).

## Diagram
```mermaid
flowchart TD
 A[Input problem] --> B[Divide into smaller subproblems]
 B --> C[Recursively solve subproblems]
 C --> D[Combine returned results]
 D --> E[Final answer]
```

## Experimental record
Run the Python file in `Implementation_Code`. Record the tested input sizes, measured times, operation counts, and hardware/software environment in the final report. Do not present a single timing as a general performance conclusion.

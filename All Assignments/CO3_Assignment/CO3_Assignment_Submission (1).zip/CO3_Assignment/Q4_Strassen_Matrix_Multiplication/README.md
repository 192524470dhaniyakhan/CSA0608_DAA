## Q4 – Strassen Matrix Multiplication
Conventional multiplication uses 8 block products and `Θ(n³)` time. Strassen uses 7:
`T(n)=7T(n/2)+Θ(n²)=Θ(n^(log₂7))≈Θ(n^2.807)`. This implementation pads a square matrix to the next power-of-two dimension, then crops the result. Padding, additions/subtractions, recursion, allocation, and cache effects can make conventional multiplication faster for small matrices.

# Decomposition, recurrence and complexity

A,B -> four blocks each -> seven recursive products -> four output blocks. T(n)=7T(n/2)+Θ(n²)=Θ(n^2.807).

## Diagram
```mermaid
flowchart TD
 A[Input problem] --> B[Divide into smaller subproblems]
 B --> C[Recursively solve subproblems]
 C --> D[Combine returned results]
 D --> E[Final answer]
```

## Experimental record
Run the Python file in `Implementation_Code`. Record the tested input sizes, measured times, operation counts, and hardware/software environment in the final report. Do not present a single timing as a general performance conclusion.

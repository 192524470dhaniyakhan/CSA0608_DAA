def add(A,B):
    n=len(A); return [[A[i][j]+B[i][j] for j in range(n)] for i in range(n)]
def sub(A,B):
    n=len(A); return [[A[i][j]-B[i][j] for j in range(n)] for i in range(n)]
def conventional(A,B):
    n=len(A); C=[[0]*n for _ in range(n)]
    for i in range(n):
        for k in range(n):
            for j in range(n): C[i][j]+=A[i][k]*B[k][j]
    return C
def strassen(A,B):
    n=len(A)
    if n<=2: return conventional(A,B)
    h=n//2
    a11=[r[:h] for r in A[:h]]; a12=[r[h:] for r in A[:h]]
    a21=[r[:h] for r in A[h:]]; a22=[r[h:] for r in A[h:]]
    b11=[r[:h] for r in B[:h]]; b12=[r[h:] for r in B[:h]]
    b21=[r[:h] for r in B[h:]]; b22=[r[h:] for r in B[h:]]
    m1=strassen(add(a11,a22),add(b11,b22))
    m2=strassen(add(a21,a22),b11)
    m3=strassen(a11,sub(b12,b22))
    m4=strassen(a22,sub(b21,b11))
    m5=strassen(add(a11,a12),b22)
    m6=strassen(sub(a21,a11),add(b11,b12))
    m7=strassen(sub(a12,a22),add(b21,b22))
    c11=add(sub(add(m1,m4),m5),m7)
    c12=add(m3,m5); c21=add(m2,m4)
    c22=add(add(sub(m1,m2),m3),m6)
    C=[[0]*n for _ in range(n)]
    for i in range(h):
        C[i][:h]=c11[i]; C[i][h:]=c12[i]
        C[i+h][:h]=c21[i]; C[i+h][h:]=c22[i]
    return C
def pad(A,n):
    old=len(A); return [row+[0]*(n-old) for row in A]+[[0]*n for _ in range(n-old)]
def multiply_strassen(A,B):
    if not A or len(A)!=len(A[0]) or len(B)!=len(B[0]) or len(A)!=len(B):
        raise ValueError("Matrices must be non-empty square matrices of equal size")
    n=len(A); p=1
    while p<n: p*=2
    C=strassen(pad(A,p),pad(B,p))
    return [row[:n] for row in C[:n]]
if __name__=="__main__":
    A=[[1,2,3],[4,5,6],[7,8,9]]
    B=[[9,8,7],[6,5,4],[3,2,1]]
    x=conventional(A,B); y=multiply_strassen(A,B)
    print("Q4 Strassen Matrix Multiplication")
    print("Conventional:",x)
    print("Strassen:",y)
    print("Correct:",x==y)
    print("Original size: 3x3; padded size: 4x4")

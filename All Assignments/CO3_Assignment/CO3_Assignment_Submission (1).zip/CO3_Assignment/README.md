# CO3 Assignment – Divide and Conquer (Pair Work)

This repository follows the folder structure and question coverage in the uploaded **CSA06 Design and Analysis of Algorithms – Assignment 3 (CO3)** brief.

## Contents
- Q1: Max-Min and Binary Search
- Q2: Merge Sort and Quick Sort (middle-position pivot)
- Q3: Standard and Karatsuba multiplication
- Q4: Conventional and Strassen matrix multiplication
- Q5: Brute-force and D&C closest pair
- Q6: Median of Medians and Meet-in-the-Middle Subset Sum
- Q7: Day-4 design challenge using Count Inversions
- Final report and student contribution record

## Run
Requires Python 3; no third-party Python packages are required. Open a terminal in the repository and run, for example:
`python Q1_MaxMin_Binary_Search/Implementation_Code/q1_maxmin_binary_search.py`

Run the corresponding `.py` file for each question. Sample execution text and PNG output captures are in each `Output_Screenshots` folder.

## Important before submission
1. Replace `[Partner Name]` and other placeholders.
2. The assignment PDF does not name a specific Q7 challenge problem. This package uses Count Inversions as an example; confirm acceptability with faculty.
3. Student A and Student B proposal files are blank templates by design. Each student must independently write their own proposal before discussion; do not claim the sample package authored their independent thinking.
4. Complete actual repeated timing experiments, increasing input-size tests, graphs, and measured performance tables. The sample outputs verify only the included test cases and do not fabricate timing results.
5. Update the contribution record to reflect actual work completed. Both students must understand all questions and prepare for viva.

## Q1 – Decomposition and Elimination
**Algorithms:** tournament-style divide-and-conquer Max-Min and iterative Binary Search.

**Recurrences**
- Max-Min: `T(n) = 2T(n/2) + 2` for even-sized recursive subproblems, with constant-size base cases; hence `O(n)` and approximately `3n/2 - 2` comparisons for a balanced pairwise tournament (exact count depends on odd-size handling).
- Binary Search: `T(n) = T(n/2) + O(1) = O(log n)`; worst-case comparisons are at most `floor(log2 n) + 1`.

**Decomposition:** split the array into two halves; each Max-Min call returns only its local minimum and maximum. Binary Search discards the half that cannot contain the target because the input is sorted.

def max_min(a, counter=None):
    if not a:
        raise ValueError("Input must not be empty")
    if len(a) == 1:
        return a[0], a[0]
    if len(a) == 2:
        if counter is not None: counter[0] += 1
        return (a[0], a[1]) if a[0] <= a[1] else (a[1], a[0])
    mid = len(a)//2
    mn1, mx1 = max_min(a[:mid], counter)
    mn2, mx2 = max_min(a[mid:], counter)
    if counter is not None: counter[0] += 2
    return min(mn1, mn2), max(mx1, mx2)

def binary_search(a, target, counter=None):
    lo, hi = 0, len(a)-1
    while lo <= hi:
        mid = (lo+hi)//2
        if counter is not None: counter[0] += 1
        if a[mid] == target: return mid
        if target < a[mid]: hi = mid-1
        else: lo = mid+1
    return -1

if __name__ == "__main__":
    data = [7, 2, 9, 1, 5, 8, 3]
    c=[0]; mn,mx=max_min(data,c)
    print("Q1A Max-Min")
    print("Data:", data, "| Minimum:", mn, "| Maximum:", mx, "| Counted comparisons:", c[0])
    ordered=sorted(data)
    for target in (5, 4):
        c=[0]; pos=binary_search(ordered,target,c)
        print(f"Q1B Binary Search target={target}: index={pos}, comparisons={c[0]}")

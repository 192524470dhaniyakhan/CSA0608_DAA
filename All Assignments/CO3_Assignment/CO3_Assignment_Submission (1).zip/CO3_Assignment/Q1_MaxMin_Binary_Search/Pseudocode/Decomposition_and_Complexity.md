# Decomposition, recurrence and complexity

Max-Min decomposition: A -> left half + right half -> (minL,maxL) + (minR,maxR) -> global min/max. Binary Search repeatedly halves the candidate interval. Max-Min is Θ(n); Binary Search is Θ(log n).

## Diagram
```mermaid
flowchart TD
 A[Input problem] --> B[Divide into smaller subproblems]
 B --> C[Recursively solve subproblems]
 C --> D[Combine returned results]
 D --> E[Final answer]
```

## Experimental record
Run the Python file in `Implementation_Code`. Record the tested input sizes, measured times, operation counts, and hardware/software environment in the final report. Do not present a single timing as a general performance conclusion.

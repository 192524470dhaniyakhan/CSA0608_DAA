# Decomposition, recurrence and complexity

Merge Sort tree: n -> n/2+n/2 -> ... -> singletons -> merge upward. Recurrence 2T(n/2)+Θ(n). Quick Sort tree depends on pivot split sizes; balanced gives Θ(n log n), worst split 0 and n-1 gives Θ(n²).

## Diagram
```mermaid
flowchart TD
 A[Input problem] --> B[Divide into smaller subproblems]
 B --> C[Recursively solve subproblems]
 C --> D[Combine returned results]
 D --> E[Final answer]
```

## Experimental record
Run the Python file in `Implementation_Code`. Record the tested input sizes, measured times, operation counts, and hardware/software environment in the final report. Do not present a single timing as a general performance conclusion.

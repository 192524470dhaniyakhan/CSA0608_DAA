## Q2 – Quality of Decomposition in Sorting
Merge Sort always divides the input into halves: `T(n)=2T(n/2)+Θ(n)=Θ(n log n)`, with predictable recursion-tree height `Θ(log n)` and `Θ(n)` auxiliary space.

Quick Sort uses the **middle-position element as pivot** in this implementation. Its recurrence is `T(n)=T(k)+T(n-k-1)+Θ(n)`. Balanced partitions give `Θ(n log n)`; repeated extreme partitions give `Θ(n²)` and recursion depth `Θ(n)`. The experiment records partition sizes and maximum depth. Pivot strategy and input distribution affect partition quality.

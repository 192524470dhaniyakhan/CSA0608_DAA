def merge_sort(a):
    if len(a) <= 1: return a[:]
    mid=len(a)//2
    left=merge_sort(a[:mid]); right=merge_sort(a[mid:])
    out=[]; i=j=0
    while i<len(left) and j<len(right):
        if left[i] <= right[j]: out.append(left[i]); i+=1
        else: out.append(right[j]); j+=1
    return out+left[i:]+right[j:]

def quick_sort(a, depth=1, stats=None):
    if stats is None: stats={"comparisons":0,"max_depth":0,"partitions":[]}
    stats["max_depth"]=max(stats["max_depth"],depth)
    if len(a)<=1: return a[:], stats
    pivot=a[len(a)//2]  # explicitly stated middle-element pivot
    less=[]; equal=[]; greater=[]
    for x in a:
        stats["comparisons"]+=1
        if x<pivot: less.append(x)
        elif x>pivot: greater.append(x)
        else: equal.append(x)
    stats["partitions"].append((len(less),len(equal),len(greater)))
    l,_=quick_sort(less,depth+1,stats); r,_=quick_sort(greater,depth+1,stats)
    return l+equal+r,stats

if __name__=="__main__":
    cases={"mixed":[8,3,1,7,0,10,2,5],"sorted":[1,2,3,4,5,6,7,8],"reverse":[8,7,6,5,4,3,2,1]}
    print("Q2 Merge Sort and Quick Sort (middle-element pivot)")
    for name,a in cases.items():
        q,st=quick_sort(a)
        print(f"{name}: input={a}")
        print(" merge_sort =",merge_sort(a))
        print(f" quick_sort = {q}; comparisons={st['comparisons']}; max_depth={st['max_depth']}; partitions={st['partitions']}")

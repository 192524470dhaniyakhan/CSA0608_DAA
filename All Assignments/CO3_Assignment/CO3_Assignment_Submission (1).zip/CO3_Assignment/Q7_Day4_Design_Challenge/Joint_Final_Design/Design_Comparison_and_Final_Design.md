# Q7 – Day-4 Design Challenge
**Selected challenge for this prepared package:** Count the number of inversions in an array. An inversion is a pair `(i,j)` where `i < j` and `A[i] > A[j]`.

## Why this is a suitable D&C problem
The array can be split into two halves. Inversions are either entirely in the left half, entirely in the right half, or cross from left to right. Cross-inversions can be counted during merge.

## Compare independent proposals (complete after both students write theirs)
| Aspect | Student A proposal | Student B proposal | Joint decision |
|---|---|---|---|
| Decomposition | [Fill] | [Fill] | Split into two halves |
| Base case | [Fill] | [Fill] | 0 or 1 element: zero inversions |
| Returned information | [Fill] | [Fill] | Sorted subarray and inversion count |
| Combine | [Fill] | [Fill] | Merge and count cross-inversions |

## Joint final design
- Decomposition: two halves.
- Base case: subarray length at most one.
- Returned information: sorted subarray and number of inversions.
- Combine: merge sorted halves; whenever a right-side value is smaller than the current left-side value, it forms an inversion with every remaining left-side value.
- Recurrence: `T(n)=2T(n/2)+Θ(n)`.
- Complexity: `Θ(n log n)` time and `Θ(n)` auxiliary space.
- Baseline: brute force checks all pairs in `Θ(n²)` time.

## Stage 4 validation
Student A – mathematical validation: derive and explain the recurrence above, then solve by Master Theorem.
Student B – experimental validation: test sorted, reverse-sorted, duplicate-containing, empty, singleton, and mixed arrays; compare with brute force.

# Student B – Independent Design Proposal (complete before discussion)
**Student:** [Partner name]

- Proposed decomposition:
- Base case:
- Information returned by each subproblem:
- Combine strategy:
- Expected recurrence:
- Possible weakness / edge case:

**Reminder:** Write and save the partner's own proposal independently before discussion. Do not invent or attribute their thinking.

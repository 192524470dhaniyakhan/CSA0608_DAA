def count_inversions_dc(a):
    def sort_count(x):
        if len(x)<=1: return x,0
        mid=len(x)//2
        left,lc=sort_count(x[:mid]); right,rc=sort_count(x[mid:])
        merged=[]; i=j=0; cross=0
        while i<len(left) and j<len(right):
            if left[i]<=right[j]: merged.append(left[i]); i+=1
            else:
                merged.append(right[j]); j+=1
                cross+=len(left)-i
        merged.extend(left[i:]); merged.extend(right[j:])
        return merged,lc+rc+cross
    return sort_count(a)
def count_inversions_brute(a):
    return sum(1 for i in range(len(a)) for j in range(i+1,len(a)) if a[i]>a[j])
if __name__=="__main__":
    data=[2,4,1,3,5]
    sorted_data,count=count_inversions_dc(data)
    baseline=count_inversions_brute(data)
    print("Q7 Day-4 Design Challenge: Count Inversions")
    print("Input:",data)
    print("Sorted:",sorted_data)
    print("Divide-and-conquer inversion count:",count)
    print("Brute-force inversion count:",baseline)
    print("Correct:",count==baseline)

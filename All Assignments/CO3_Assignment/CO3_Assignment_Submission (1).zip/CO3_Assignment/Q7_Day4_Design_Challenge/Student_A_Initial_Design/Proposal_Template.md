# Student A – Independent Design Proposal (complete before discussion)
**Student:** Dhaniya Khan (edit if roles differ)

- Proposed decomposition:
- Base case:
- Information returned by each subproblem:
- Combine strategy:
- Expected recurrence:
- Possible weakness / edge case:

**Reminder:** Write and save your own proposal before viewing/discussing Student B's proposal. Do not copy a joint answer into this section.

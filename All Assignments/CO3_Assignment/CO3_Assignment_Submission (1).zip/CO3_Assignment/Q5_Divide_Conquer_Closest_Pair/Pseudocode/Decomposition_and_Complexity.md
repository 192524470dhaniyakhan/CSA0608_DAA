# Decomposition, recurrence and complexity

Points -> left/right x partitions -> closest pair in each -> boundary strip check -> minimum. Textbook optimized recurrence 2T(n/2)+Θ(n)=Θ(n log n). This code's repeated strip sorting may add a log factor.

## Diagram
```mermaid
flowchart TD
 A[Input problem] --> B[Divide into smaller subproblems]
 B --> C[Recursively solve subproblems]
 C --> D[Combine returned results]
 D --> E[Final answer]
```

## Experimental record
Run the Python file in `Implementation_Code`. Record the tested input sizes, measured times, operation counts, and hardware/software environment in the final report. Do not present a single timing as a general performance conclusion.

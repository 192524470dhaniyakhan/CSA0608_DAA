import math, random
def dist(p,q): return math.hypot(p[0]-q[0],p[1]-q[1])
def brute(points):
    best=float("inf"); pair=None; count=0
    for i in range(len(points)):
        for j in range(i+1,len(points)):
            count+=1; d=dist(points[i],points[j])
            if d<best: best,pair=d,(points[i],points[j])
    return best,pair,count
def closest_pair(points):
    pts=sorted(points)
    def rec(px):
        n=len(px)
        if n<=3: return brute(px)[:2]
        mid=n//2; midx=px[mid][0]
        dl,pl=rec(px[:mid]); dr,pr=rec(px[mid:])
        best,pair=(dl,pl) if dl<=dr else (dr,pr)
        strip=[p for p in px if abs(p[0]-midx)<best]
        strip.sort(key=lambda p:p[1])
        for i in range(len(strip)):
            j=i+1
            while j<len(strip) and strip[j][1]-strip[i][1]<best:
                d=dist(strip[i],strip[j])
                if d<best: best,pair=d,(strip[i],strip[j])
                j+=1
        return best,pair
    return rec(pts)
if __name__=="__main__":
    points=[(2,3),(12,30),(40,50),(5,1),(12,10),(3,4),(8,9),(7,7)]
    b=brute(points); d=closest_pair(points)
    print("Q5 Closest Pair")
    print("Points:",points)
    print("Brute force distance/pair/checks:",b)
    print("Divide-and-conquer distance/pair:",d)
    print("Same minimum distance:",math.isclose(b[0],d[0]))
